var file = 'images/slack.png';
var url = chrome.extension.getURL(file);

setInterval(function() {
  document.querySelector('link[rel*="icon"]').href = url;
}, 150)

